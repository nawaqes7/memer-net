export const categories = [
  { id: '1', name: 'الرئيسية', path: '/' },
  { id: '2', name: 'أخبار محلية', path: '/local' },
  { id: '3', name: 'أخبار عربية ودولية', path: '/world' },
  { id: '4', name: 'اقتصاد', path: '/economy' },
  { id: '5', name: 'رياضة', path: '/sports' },
  { id: '6', name: 'مقالات', path: '/articles' },
  { id: '7', name: 'تقارير وتحقيقات', path: '/reports' },
  { id: '8', name: 'منوعات', path: '/variety' },
];

export const breakingNews = [
  "عاجل | الحكومة تعلن عن حزمة قرارات جديدة لدعم الاقتصاد الوطني",
  "عاجل | ارتفاع ملحوظ في مؤشرات الأسواق المالية اليوم",
  "عاجل | وزارة الصحة تصدر بياناً هاماً بشأن الإجراءات الوقائية الجديدة",
  "عاجل | المنتخب الوطني يحقق فوزاً تاريخياً في التصفيات المؤهلة للبطولة القارية"
];

export const featuredNews = [
  {
    id: '1',
    title: 'تطورات متسارعة في الساحة السياسية: لقاءات مكثفة لرسم خارطة الطريق',
    excerpt: 'شهدت العاصمة اليوم سلسلة من اللقاءات السياسية المكثفة بمشاركة واسعة من مختلف الأطياف...',
    image: 'https://images.unsplash.com/photo-1541872526-249c185a7b0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    category: 'أخبار محلية',
    date: 'منذ ساعتين'
  },
  {
    id: '2',
    title: 'اكتشاف أثري جديد يعود لآلاف السنين في المنطقة الجنوبية',
    excerpt: 'أعلنت وزارة الآثار عن اكتشاف مدينة كاملة تحت الأرض تعود للعصر البرونزي...',
    image: 'https://images.unsplash.com/photo-1544208287-39322bb1e17d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    category: 'تقارير وتحقيقات',
    date: 'منذ 4 ساعات'
  },
  {
    id: '3',
    title: 'قفزة غير مسبوقة في صادرات التكنولوجيا الوطنية هذا العام',
    excerpt: 'أظهرت التقارير الاقتصادية نمواً بنسبة 45% في صادرات قطاع التكنولوجيا مقارنة بالعام الماضي.',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    category: 'اقتصاد',
    date: 'منذ 5 ساعات'
  }
];

export const recentNews = [
  {
    id: '4',
    title: 'توقيع اتفاقية شراكة استراتيجية لتطوير البنية التحتية',
    image: 'https://images.unsplash.com/photo-1541888062828-8d9620b72c6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
    category: 'اقتصاد',
    date: 'منذ 6 ساعات'
  },
  {
    id: '5',
    title: 'استعدادات مكثفة لانطلاق مهرجان الثقافة والفنون السنوي',
    image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
    category: 'منوعات',
    date: 'منذ 8 ساعات'
  },
  {
    id: '6',
    title: 'تحذيرات من منخفض جوي عميق يضرب المنطقة نهاية الأسبوع',
    image: 'https://images.unsplash.com/photo-1561484930-998b6a7b22e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
    category: 'أخبار محلية',
    date: 'منذ 10 ساعات'
  },
  {
    id: '7',
    title: 'فريق العاصمة يتوج بلقب الدوري المحلي بعد مباراة دراماتيكية',
    image: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
    category: 'رياضة',
    date: 'منذ 12 ساعة'
  }
];

export const popularNews = [
  {
    id: '8',
    title: 'كيف ستؤثر القرارات الاقتصادية الجديدة على جيب المواطن؟',
    date: '12 مايو 2024'
  },
  {
    id: '9',
    title: 'أسرار تكشف لأول مرة عن المفاوضات الأخيرة',
    date: '11 مايو 2024'
  },
  {
    id: '10',
    title: 'طرق طبيعية لتقوية المناعة في فصل الشتاء',
    date: '10 مايو 2024'
  },
  {
    id: '11',
    title: 'أفضل الوجهات السياحية الداخلية التي يجب زيارتها',
    date: '09 مايو 2024'
  },
  {
    id: '12',
    title: 'تحليل فني: أسباب تراجع أداء المنتخب في البطولة الأخيرة',
    date: '08 مايو 2024'
  }
];