import { useState } from 'react';
import { Search, Facebook, Twitter, Instagram, Youtube, Menu, X, Clock } from 'lucide-react';
import { categories } from '../data/mockData';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const currentDate = format(new Date(), 'EEEE, d MMMM yyyy', { locale: ar });

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      {/* Top Bar */}
      <div className="bg-gray-900 text-gray-300 text-xs py-1.5 border-b border-gray-800">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-4 space-x-reverse">
            <span className="flex items-center gap-1">
              <Clock size={14} />
              {currentDate}
            </span>
          </div>
          <div className="flex items-center space-x-3 space-x-reverse">
            <a href="#" className="hover:text-white transition-colors"><Facebook size={14} /></a>
            <a href="#" className="hover:text-white transition-colors"><Twitter size={14} /></a>
            <a href="#" className="hover:text-white transition-colors"><Instagram size={14} /></a>
            <a href="#" className="hover:text-white transition-colors"><Youtube size={14} /></a>
          </div>
        </div>
      </div>

      {/* Main Header area */}
      <div className="container mx-auto px-4 py-4 md:py-6">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex-shrink-0">
            <a href="/" className="flex items-center gap-2">
              <div className="text-[#cc0000] font-black text-4xl md:text-5xl tracking-tighter">
                ميمر <span className="text-gray-900">نت</span>
              </div>
            </a>
          </div>

          {/* Ad Banner (Placeholder) */}
          <div className="hidden md:flex w-full max-w-[728px] h-[90px] bg-gray-100 items-center justify-center border border-gray-200 text-gray-400 text-sm rounded">
            مساحة إعلانية (728x90)
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-600 hover:text-blue-600"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-[#cc0000] text-white">
        <div className="container mx-auto px-4">
          {/* Desktop Nav */}
          <div className="hidden md:flex justify-between items-center h-14">
            <ul className="flex items-center h-full">
              {categories.map((category) => (
                <li key={category.id} className="h-full">
                  <a 
                    href={category.path} 
                    className="flex items-center h-full px-4 font-bold text-[15px] hover:bg-red-800 transition-colors relative group"
                  >
                    {category.name}
                    {category.id === '1' && (
                      <span className="absolute bottom-0 left-0 w-full h-1 bg-white"></span>
                    )}
                  </a>
                </li>
              ))}
            </ul>
            <div className="flex items-center bg-red-800 px-3 py-1.5 rounded-sm">
              <input 
                type="text" 
                placeholder="بحث..." 
                className="bg-transparent border-none text-white text-sm outline-none w-48 placeholder-red-200"
              />
              <Search size={18} className="text-white cursor-pointer" />
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        {isMenuOpen && (
          <div className="md:hidden bg-[#cc0000] border-t border-red-800">
            <ul className="flex flex-col py-2">
              {categories.map((category) => (
                <li key={category.id}>
                  <a 
                    href={category.path} 
                    className="block px-4 py-3 hover:bg-red-800 border-b border-red-800 text-white font-medium"
                  >
                    {category.name}
                  </a>
                </li>
              ))}
            </ul>
            <div className="p-4 border-t border-red-800">
              <div className="flex items-center bg-red-800 px-3 py-2 rounded">
                <input 
                  type="text" 
                  placeholder="بحث..." 
                  className="bg-transparent border-none text-white outline-none w-full placeholder-red-200"
                />
                <Search size={20} className="text-white ml-2" />
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;