import { Facebook, Twitter, Instagram, Youtube, Phone, Mail, MapPin } from 'lucide-react';
import { categories } from '../data/mockData';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 pt-16 border-t-[5px] border-[#cc0000]">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Column 1 - About */}
          <div className="space-y-6">
            <div className="text-[#cc0000] bg-white inline-block font-black text-3xl px-3 py-1 rounded-sm shadow-md mb-4 tracking-tighter">
              ميمر <span className="text-gray-900">نت</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              ميمر نت هو موقع إخباري شامل، يغطي كافة الأحداث المحلية والدولية، بالإضافة إلى التحليلات والتقارير المعمقة، على مدار الساعة بمصداقية ومهنية عالية.
            </p>
            <div className="flex gap-4">
              <a href="#" className="bg-blue-800 p-2 rounded-full hover:bg-blue-600 transition-colors text-white">
                <Facebook size={18} />
              </a>
              <a href="#" className="bg-blue-400 p-2 rounded-full hover:bg-blue-300 transition-colors text-white">
                <Twitter size={18} />
              </a>
              <a href="#" className="bg-pink-600 p-2 rounded-full hover:bg-pink-500 transition-colors text-white">
                <Instagram size={18} />
              </a>
              <a href="#" className="bg-red-600 p-2 rounded-full hover:bg-red-500 transition-colors text-white">
                <Youtube size={18} />
              </a>
            </div>
          </div>

          {/* Column 2 - Quick Links */}
          <div>
            <h3 className="text-white text-lg font-bold mb-6 border-b border-gray-700 pb-3 inline-block">روابط هامة</h3>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-[#cc0000] transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-[#cc0000] rounded-full"></span> من نحن</a></li>
              <li><a href="#" className="hover:text-[#cc0000] transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-[#cc0000] rounded-full"></span> سياسة الخصوصية</a></li>
              <li><a href="#" className="hover:text-[#cc0000] transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-[#cc0000] rounded-full"></span> شروط الاستخدام</a></li>
              <li><a href="#" className="hover:text-[#cc0000] transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-[#cc0000] rounded-full"></span> اتصل بنا</a></li>
              <li><a href="#" className="hover:text-[#cc0000] transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-[#cc0000] rounded-full"></span> للإعلان معنا</a></li>
            </ul>
          </div>

          {/* Column 3 - Categories */}
          <div>
            <h3 className="text-white text-lg font-bold mb-6 border-b border-gray-700 pb-3 inline-block">الأقسام</h3>
            <ul className="grid grid-cols-2 gap-3 text-sm">
              {categories.slice(1).map((category) => (
                <li key={`footer-${category.id}`}>
                  <a href={category.path} className="hover:text-[#cc0000] transition-colors flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-gray-500 rounded-full group-hover:bg-[#cc0000]"></span>
                    {category.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4 - Contact */}
          <div>
            <h3 className="text-white text-lg font-bold mb-6 border-b border-gray-700 pb-3 inline-block">تواصل معنا</h3>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-[#cc0000] shrink-0 mt-0.5" />
                <span className="text-gray-400 leading-relaxed">شارع الصحافة الرئيسي، مبنى الإعلاميات، الطابق الرابع، العاصمة</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-[#cc0000] shrink-0" />
                <span className="text-gray-400" dir="ltr">+123 456 789 000</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-[#cc0000] shrink-0" />
                <span className="text-gray-400">info@mimernet.com</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="bg-black py-4 border-t border-gray-800 text-center">
        <p className="text-gray-500 text-xs md:text-sm px-4">
          جميع الحقوق محفوظة &copy; {new Date().getFullYear()} ميمر نت - الموقع الإخباري الأول. تم التطوير بواسطة Mimer.
        </p>
      </div>
    </footer>
  );
};

export default Footer;