import { Clock, ChevronLeft } from 'lucide-react';
import { recentNews, popularNews } from '../data/mockData';

const MainContent = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
      {/* Main Articles Area */}
      <div className="lg:col-span-2 space-y-8">
        {/* Section Header */}
        <div className="flex justify-between items-center border-b-2 border-gray-200 pb-2 mb-6">
          <h2 className="text-2xl font-bold text-gray-800 relative">
            <span className="absolute bottom-[-10px] right-0 w-1/2 h-[2px] bg-[#cc0000]"></span>
            أحدث الأخبار
          </h2>
          <a href="#" className="text-sm font-medium text-[#cc0000] flex items-center hover:text-red-800 transition-colors">
            المزيد <ChevronLeft size={16} />
          </a>
        </div>

        {/* Article List */}
        <div className="space-y-6">
          {recentNews.map((article) => (
            <article key={article.id} className="flex flex-col md:flex-row gap-4 group">
              {/* Image */}
              <div className="md:w-1/3 shrink-0 rounded-lg overflow-hidden h-48 md:h-36 shadow-sm">
                <a href="#" className="block h-full w-full relative">
                  <img 
                    src={article.image} 
                    alt={article.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute top-2 right-2 bg-[#cc0000] text-white text-[10px] font-bold px-2 py-1 rounded">
                    {article.category}
                  </div>
                </a>
              </div>
              
              {/* Content */}
              <div className="flex-1 flex flex-col justify-between py-1">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 leading-snug group-hover:text-[#cc0000] transition-colors mb-2 line-clamp-2">
                    <a href="#">{article.title}</a>
                  </h3>
                  <p className="text-gray-600 text-sm line-clamp-2 mb-3">
                    لوريم إيبسوم دولار سيت أميت، كونسيكتيتور أدايبا يسكينج أليايت، سيت دو أيوسمود تيمبور أنكايديديونتيوت لابوري إت دولار ماجنا أليكيوا...
                  </p>
                </div>
                <div className="flex items-center text-gray-500 text-xs font-medium gap-1.5">
                  <Clock size={12} />
                  <span>{article.date}</span>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Second Category Box */}
        <div className="mt-12">
          <div className="flex justify-between items-center border-b-2 border-gray-200 pb-2 mb-6">
            <h2 className="text-2xl font-bold text-gray-800 relative">
              <span className="absolute bottom-[-10px] right-0 w-1/2 h-[2px] bg-red-600"></span>
              أخبار مختارة
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {recentNews.slice(0, 2).map((article) => (
              <div key={`box-${article.id}`} className="group cursor-pointer">
                <div className="rounded-lg overflow-hidden mb-3 shadow-sm h-48">
                  <img 
                    src={article.image} 
                    alt={article.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <h3 className="text-lg font-bold text-gray-800 group-hover:text-red-600 transition-colors line-clamp-2 mb-2">
                  {article.title}
                </h3>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sidebar */}
      <aside className="space-y-8">
        {/* Most Read Box */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
          <h3 className="text-lg font-bold border-b border-gray-200 pb-3 mb-4 flex items-center gap-2">
            <span className="w-2 h-6 bg-[#cc0000] rounded-sm inline-block"></span>
            الأكثر قراءة
          </h3>
          <ul className="space-y-4">
            {popularNews.map((news, index) => (
              <li key={news.id} className="flex gap-4 group cursor-pointer border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                <span className="text-2xl font-black text-gray-300 group-hover:text-[#cc0000] transition-colors w-6 text-center">
                  {index + 1}
                </span>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm leading-snug group-hover:text-[#cc0000] transition-colors line-clamp-2">
                    {news.title}
                  </h4>
                  <div className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                    <Clock size={10} />
                    {news.date}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Ad Placeholder Box */}
        <div className="bg-gray-100 w-full h-[300px] flex items-center justify-center border border-gray-200 text-gray-400 rounded-lg">
          <div className="text-center">
            <p className="font-medium text-sm mb-1">إعلان</p>
            <p className="text-xs">300x250</p>
          </div>
        </div>

        {/* Newsletter Box */}
        <div className="bg-gray-900 rounded-lg p-6 text-white text-center">
          <h3 className="text-xl font-bold mb-2">النشرة البريدية</h3>
          <p className="text-gray-400 text-sm mb-5 leading-relaxed">
            اشترك في النشرة البريدية ليصلك أهم الأخبار والتقارير حصرياً
          </p>
          <form className="space-y-3">
            <input 
              type="email" 
              placeholder="البريد الإلكتروني" 
              className="w-full px-4 py-2 rounded text-gray-900 text-sm text-center outline-none focus:ring-2 focus:ring-[#cc0000]"
            />
            <button 
              type="button" 
              className="w-full bg-[#cc0000] hover:bg-red-700 text-white font-bold py-2 rounded transition-colors"
            >
              اشتراك
            </button>
          </form>
        </div>
      </aside>
    </div>
  );
};

export default MainContent;