import { Zap } from 'lucide-react';
import { breakingNews } from '../data/mockData';

const BreakingNews = () => {
  return (
    <div className="bg-[#cc0000] text-white flex items-center overflow-hidden mb-6 shadow-sm border-b-4 border-black">
      <div className="bg-black px-4 py-2 font-bold flex items-center gap-2 whitespace-nowrap z-10 shrink-0">
        <Zap size={18} className="fill-current text-[#cc0000]" />
        شريط الأخبار
      </div>
      <div className="ticker-wrap flex-1 overflow-hidden relative h-full flex items-center bg-[#cc0000] text-white">
        <div className="ticker-move flex items-center">
          {breakingNews.map((news, index) => (
            <span key={index} className="px-8 inline-block font-semibold whitespace-nowrap">
              {news}
            </span>
          ))}
          {/* Duplicate for seamless loop */}
          {breakingNews.map((news, index) => (
            <span key={`dup-${index}`} className="px-8 inline-block font-semibold whitespace-nowrap">
              {news}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BreakingNews;