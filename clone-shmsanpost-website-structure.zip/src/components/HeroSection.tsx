import { featuredNews } from '../data/mockData';
import { Clock } from 'lucide-react';

const HeroSection = () => {
  const mainNews = featuredNews[0];
  const sideNews = featuredNews.slice(1, 3);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8">
      {/* Main Featured News */}
      <div className="lg:col-span-2 relative group overflow-hidden rounded-lg shadow-lg aspect-video">
        <a href="#" className="block w-full h-full">
          <img 
            src={mainNews.image} 
            alt={mainNews.title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-6">
            <span className="bg-[#cc0000] text-white text-xs font-bold px-3 py-1 rounded-sm w-fit mb-3 uppercase tracking-wider">
              {mainNews.category}
            </span>
            <h2 className="text-white text-2xl md:text-3xl font-bold leading-tight mb-2 group-hover:text-[#cc0000] transition-colors line-clamp-2">
              {mainNews.title}
            </h2>
            <div className="flex items-center text-gray-300 text-sm gap-2 mt-2">
              <Clock size={14} />
              <span>{mainNews.date}</span>
            </div>
          </div>
        </a>
      </div>

      {/* Side Featured News */}
      <div className="flex flex-col gap-4">
        {sideNews.map((news) => (
          <div key={news.id} className="relative group overflow-hidden rounded-lg shadow-md flex-1 min-h-[200px]">
            <a href="#" className="block w-full h-full">
              <img 
                src={news.image} 
                alt={news.title} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-4">
                <span className="bg-[#cc0000] text-white text-xs font-bold px-2 py-1 rounded-sm w-fit mb-2">
                  {news.category}
                </span>
                <h3 className="text-white text-lg font-bold leading-tight group-hover:text-[#cc0000] transition-colors line-clamp-2">
                  {news.title}
                </h3>
              </div>
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HeroSection;